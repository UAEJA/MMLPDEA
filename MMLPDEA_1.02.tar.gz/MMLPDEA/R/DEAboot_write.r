#############################################################################################
DEAboot_write=function(X,Y,orient='in',RTS='crs',nboot=250,bootlist=NULL,alpha=0.05,
seedval=1001,MMLPV=2,itermax=1000,pullDATA=FALSE,fname='DEAboot_data.csv'){
#############################################################################################
 if(!is.matrix(X)) X=as.matrix(X)
 if(!is.matrix(Y)) Y=as.matrix(Y)
 (nDMU=nrow(X));(nX=ncol(X));(nY=ncol(Y))

 if(is.null(bootlist)) bootlist=1:nDMU
 (nDMUboot=length(bootlist))

 if(orient=='in'|orient=='IN')    (orient=1)
 if(orient=='out'|orient=='OUT')  (orient=2)

 if(RTS=='crs'|RTS=='CRS')        RTS=3
 if(RTS=='vrs'|RTS=='VRS')        RTS=1
 if(RTS=='drs'|RTS=='DRS')        RTS=2
 if(RTS=='irs'|RTS=='IRS')        RTS=4

 if(orient!=1&orient!=2)           orient=1 
 if(RTS!=1&RTS!=2&RTS!=3&RTS!=4)   RTS=3
 
 h=0.0
 effvals=rep(0,nDMU);effstatus=effvals
 boot=matrix(0,nDMUboot,nboot);bootstatus=boot

 pullDATA=ifelse(pullDATA==TRUE|pullDATA==T,1,0)

 if(pullDATA==1){nrSDRC=nDMU;ncSRC=nDMU+1;ncDL=nY+nX+1}
 if(pullDATA!=1) {nrSDRC=1;ncSRC=1;ncDL=1}


 LPsol=matrix(0,nrSDRC,ncSRC)
 DUALS=matrix(0,nrSDRC,ncDL)
 RC=matrix(0,nrSDRC,ncSRC)
 
 iternum=effstatus
 iternumboot=bootstatus
##########################################################
# DEA rescaling for increased numerical stability 
 (xscale=apply(X,2,max))
 (yscale=apply(Y,2,max))
 XS=as.matrix(t(t(X)/xscale))
 YS=as.matrix(t(t(Y)/yscale))
##########################################################
# Fortran Data
###########################################
tmp1=data.frame(cbind(orient,RTS,nboot,nDMU,nY,nX,nDMUboot,
seedval,MMLPV,itermax,pullDATA,nrSDRC,ncSRC,ncDL))

write.table(tmp1,file=fname,row.names=F,sep=',')

tmp2=data.frame(bootlist)
write.table(tmp2,file=fname,row.names=F,sep=',',append=T)


XY=data.frame(cbind(X,Y))
names(XY)=c(paste('x',1:nX,sep=''),paste('y',1:nY,sep=''))
write.table(XY,file=fname,row.names=F,sep=',',append=T)
#############################################        
} # end function DEAboot_write
###########################################################        
