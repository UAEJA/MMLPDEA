###############################################
normgen=function(n=1,seedval=1) {
###############################################
# Fortran Call
###############################################
returned_data=.Fortran('normgen', 
  n=as.integer(n),
  seedval=as.integer(seedval),
  x=as.double(rep(0.0,n)),
  PACKAGE="MMLPDEA")
###############################################        
 x=returned_data$x
 return(x)
}
###############################################        
