###############################################
ugen=function(n=1,seedval=1) {
################################################
# Fortran Call
################################################
# R package
 returned_data=.Fortran('ugen', 
  n=as.integer(n),
  seedval=as.integer(seedval),
  x=as.double(rep(0.0,n)),
  PACKAGE="MMLPDEA")
###########################################################        
 x=returned_data$x
 return(x)
}
###########################################################        

